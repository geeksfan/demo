import React from 'react'
import App from './App.jsx'

export default <App />
